# Brandtelling® Story Builder — Quick Start Checklist

## Pre-Deployment Setup (One Time)

- [ ] **Node.js & npm installed**
  - Verify: `node --version` (should be 18+)
  - Verify: `npm --version` (should be 9+)

- [ ] **Git installed**
  - Verify: `git --version`
  - Set user: `git config --global user.name "Your Name"`
  - Set email: `git config --global user.email "your@email.com"`

- [ ] **GitHub account created**
  - Go to [github.com](https://github.com)
  - Confirm email

- [ ] **Netlify account created**
  - Go to [netlify.com](https://netlify.com)
  - Sign up (free tier is fine)
  - Confirm email

- [ ] **Domain registrar access**
  - You have login credentials to wherever your `brandtelling.net` domain is hosted
  - Can access DNS settings (GoDaddy, Namecheap, Route 53, etc.)

---

## Local Repository Setup

- [ ] **Create local folder**
  ```bash
  mkdir brandtelling-story-builder
  cd brandtelling-story-builder
  ```

- [ ] **Copy all files from `/mnt/user-data/outputs/`**
  - `package.json`
  - `vite.config.js`
  - `netlify.toml`
  - `.gitignore`
  - `index.html`
  - `src/main.jsx`
  - `src/StoryBuilder.jsx`
  - Documentation files (optional)

- [ ] **Initialize Git**
  ```bash
  git init
  git config user.email "arthur@brandtelling.com"
  git config user.name "Arthur Germain"
  ```

- [ ] **Install npm dependencies**
  ```bash
  npm install
  ```
  (Wait ~2 min; should complete without errors)

- [ ] **Test locally**
  ```bash
  npm run dev
  ```
  - Browser opens to `http://localhost:3000`
  - Story Builder loads
  - All 21 questions display
  - Styling (Navy/Gold/Cream) is correct
  - Stop with `Ctrl+C`

---

## GitHub Repository

- [ ] **Create repository on GitHub**
  - Go to [github.com/new](https://github.com/new)
  - Name: `brandtelling-story-builder`
  - Public (optional, but recommended)
  - Do NOT add README, .gitignore, license
  - Click **Create repository**

- [ ] **Push local code to GitHub**
  ```bash
  git add .
  git commit -m "Initial commit: Story Builder with Navy/Gold design system"
  git branch -M main
  git remote add origin https://github.com/YOUR-USERNAME/brandtelling-story-builder.git
  git push -u origin main
  ```
  (Replace `YOUR-USERNAME`)

- [ ] **Verify on GitHub**
  - Go to your repo on github.com
  - See all files listed (package.json, src/, etc.)

---

## Netlify Deployment

- [ ] **Connect Netlify to GitHub**
  - Log into [app.netlify.com](https://app.netlify.com)
  - Click **Add new site** → **Import an existing project**
  - Select **GitHub** as Git provider
  - Search for `brandtelling-story-builder` and click it
  - Click **Install**

- [ ] **Verify build settings**
  - Branch: `main`
  - Build command: `npm run build`
  - Publish directory: `dist`
  - Click **Deploy site**

- [ ] **Wait for build**
  - Netlify shows build logs
  - Takes 2–3 minutes
  - Look for green checkmark "Deploy successful"
  - Copy the auto-generated URL (e.g., `https://XXXXXX.netlify.app`)

- [ ] **Test on Netlify URL**
  - Visit the auto-generated URL
  - Story Builder loads
  - All questions work
  - Download button generates file

---

## Custom Domain Setup

- [ ] **Add custom domain in Netlify**
  - Go to site settings
  - **Domain management** → **Add custom domain**
  - Enter `story.brandtelling.net`
  - Click **Add domain**

- [ ] **Update DNS records**
  - Netlify provides CNAME record to add
  - Log into your domain registrar (GoDaddy, Namecheap, etc.)
  - Add CNAME record:
    - Name: `story`
    - Value: (copy from Netlify)
    - TTL: 3600
  - Save

- [ ] **Wait for DNS propagation**
  - Typically 5–30 minutes
  - Netlify shows status "Checking DNS configuration"
  - Refresh Netlify dashboard every 5 min
  - When green, DNS is live

- [ ] **Test custom domain**
  - Visit `https://story.brandtelling.net` (when DNS propagates)
  - HTTPS certificate auto-activated
  - Green lock icon in browser address bar
  - Story Builder fully functional

---

## Post-Deployment Verification

- [ ] **Site loads**
  - `https://story.brandtelling.net` works
  - No 404 or timeout errors

- [ ] **Full flow works**
  - Welcome screen displays
  - Answer Q1 (Company Name)
  - Answer Q2 (Role)
  - Progress bar shows 9%
  - Click Next repeatedly through all 21 questions
  - Review screen displays all sections
  - Click Download
  - File downloads as `COMPANY-NAME-brandtelling-story-builder.md`

- [ ] **Design system verified**
  - Navy headings visible
  - Gold labels and buttons visible
  - Cream page background
  - White card backgrounds
  - All colors match design system

- [ ] **Mobile responsive**
  - Open in mobile browser (or DevTools device emulation)
  - Cards and inputs stack properly
  - No horizontal scrolling
  - Buttons fit without overlapping

- [ ] **No console errors**
  - Open browser DevTools (F12)
  - Go to Console tab
  - Should be empty (no red errors)
  - Only blue info messages are OK

- [ ] **Form validation works**
  - Click "Next" without filling a required field
  - Error message appears: "Please complete this field before continuing"
  - Button stays disabled until field filled

---

## Ongoing Maintenance

- [ ] **Set up auto-deploys**
  - Every `git push` to `main` auto-deploys
  - No manual action needed after push

- [ ] **Monitor builds**
  - Bookmark `https://app.netlify.com` dashboard
  - Check **Deploys** tab after pushing changes
  - All deploys should show green checkmark

- [ ] **Test after each change**
  - After push, wait 1–2 min
  - Visit `https://story.brandtelling.net`
  - Verify changes are live
  - Test the full flow end-to-end

---

## Troubleshooting Checklist

**If deployment fails:**
- [ ] Check Netlify build logs (Deploy → View log)
- [ ] Verify `npm install` ran successfully locally
- [ ] Confirm all files copied correctly
- [ ] Run `npm run build` locally to catch errors before push
- [ ] Check for typos in `package.json`

**If site doesn't load:**
- [ ] Check DNS propagation (use `nslookup story.brandtelling.net`)
- [ ] Wait 15+ minutes for TTL to expire
- [ ] Clear browser cache (Ctrl+Shift+Del)
- [ ] Try incognito/private window

**If styling is broken:**
- [ ] Open DevTools → Console tab
- [ ] Look for JavaScript errors
- [ ] Verify inline styles are rendering (inspect element)
- [ ] Check that `StoryBuilder.jsx` has all color definitions

**If download doesn't work:**
- [ ] Try different browser (Chrome, Firefox, Safari)
- [ ] Check browser console for errors
- [ ] Verify file actually downloads (check Downloads folder)
- [ ] Try with company name containing only alphanumeric characters

---

## Success Indicators

✅ Site lives at `https://story.brandtelling.net`  
✅ All 21 questions display and save answers  
✅ Review screen aggregates all responses  
✅ Download generates valid Markdown file  
✅ HTTPS certificate is valid (green lock)  
✅ Mobile view is responsive  
✅ Form validation prevents skipping required fields  
✅ No JavaScript errors in console  

---

## Next Steps (Optional)

- Add passcode protection (requires system prompt in Netlify function)
- Add Google Analytics to track usage
- Set up email notifications for downloads (requires backend)
- Add password reset flow
- Link to booking page or CRM
- Add A/B testing for different question flows

---

## Support

If you get stuck:

1. **Check the detailed guide:** Read `NETLIFY-DEPLOYMENT.md`
2. **Check file structure:** Read `FILE-STRUCTURE.md`
3. **Search common issues:** Google "{error message} netlify vite react"
4. **Contact Netlify support:** [support.netlify.com](https://support.netlify.com)
5. **Check local setup:** Verify `npm run dev` works before pushing

---

**Timeline:** First-time setup typically takes **1–2 hours** (mostly DNS propagation wait time).  
**Ongoing updates:** Just `git push` — Netlify handles the rest.

---

Brandtelling® Story Builder · AHG3, Inc.
