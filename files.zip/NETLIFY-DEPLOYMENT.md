# Brandtelling® Story Builder — Netlify Deployment Guide

## Overview

This guide walks you through deploying the Story Builder to Netlify at `https://story.brandtelling.net` (or your desired subdomain). The setup follows the same architecture as your MSP voice tool at `https://msp.brandtelling.net`.

---

## Prerequisites

- **Git** (installed locally; use GitHub Desktop on Windows if you prefer GUI)
- **Node.js 18+** and npm installed
- **GitHub account** (free tier works fine)
- **Netlify account** (free tier works fine)

---

## Step 1: Prepare Your Local Repository

### 1.1 Create a new folder

```bash
mkdir brandtelling-story-builder
cd brandtelling-story-builder
```

### 1.2 Initialize Git

```bash
git init
git config user.email "arthur@brandtelling.com"
git config user.name "Arthur Germain"
```

### 1.3 Copy files into the folder

Copy these files from `/mnt/user-data/outputs/` into your local folder:

```
brandtelling-story-builder/
├── package.json
├── vite.config.js
├── netlify.toml
├── .gitignore
├── index.html
└── src/
    ├── main.jsx
    └── StoryBuilder.jsx
```

### 1.4 Install dependencies

```bash
npm install
```

This downloads React, React-DOM, Lucide icons, Vite, and the Vite React plugin.

### 1.5 Test locally

```bash
npm run dev
```

Open `http://localhost:3000` in your browser. The Story Builder should load with the Navy/Gold/Cream design system.

---

## Step 2: Push to GitHub

### 2.1 Create a new repository on GitHub

1. Go to [github.com/new](https://github.com/new)
2. **Repository name:** `brandtelling-story-builder`
3. **Description:** `Brandtelling® Story Builder — Brand guardrails in 20 minutes`
4. **Public** (recommended for transparency)
5. Do NOT initialize with README, .gitignore, or license (you have these already)
6. Click **Create repository**

### 2.2 Add remote and push

```bash
git add .
git commit -m "Initial commit: Story Builder with Navy/Gold design system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/brandtelling-story-builder.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

---

## Step 3: Deploy to Netlify

### 3.1 Connect Netlify to GitHub

1. Go to [app.netlify.com](https://app.netlify.com)
2. Click **Add new site** → **Import an existing project**
3. Choose **GitHub** as your Git provider
4. Search for `brandtelling-story-builder` and select it
5. Click **Install** to authorize Netlify to access your GitHub repos

### 3.2 Configure build settings

Netlify should auto-detect these, but verify:

- **Owner:** Your Netlify team
- **Branch to deploy:** `main`
- **Build command:** `npm run build`
- **Publish directory:** `dist`
- **Functions directory:** (leave blank)

### 3.3 Deploy

Click **Deploy site**. Netlify will:
1. Clone your repository
2. Run `npm install`
3. Run `npm run build` (generates the `dist/` folder)
4. Publish the contents to a Netlify URL (e.g., `https://XXX.netlify.app`)

Wait 2–3 minutes for the build to complete.

---

## Step 4: Set Up Custom Domain

### 4.1 In Netlify

1. Go to your site's **Settings** → **Domain management**
2. Click **Add custom domain**
3. Enter `story.brandtelling.net`
4. Netlify will check DNS and likely ask you to update your DNS records

### 4.2 Update DNS records

You'll need access to your domain registrar (GoDaddy, Namecheap, etc.) or your DNS provider (e.g., Route 53 if you use AWS).

Netlify will give you specific DNS records to add. Example:

```
Type: CNAME
Name: story
Value: brandtelling-story-builder.netlify.app
TTL: 3600
```

Add this record in your domain registrar's DNS settings. Propagation typically takes 5–30 minutes.

### 4.3 Enable HTTPS

Netlify automatically provisions an SSL certificate via Let's Encrypt. HTTPS will be live after DNS propagates.

---

## Step 5: Verify Deployment

Once DNS propagates:

1. Visit `https://story.brandtelling.net`
2. The Story Builder should load with the full 21-question flow
3. Try the Welcome screen, a few questions, and the Review → Download flow
4. Download a test file and verify it opens as valid Markdown

---

## Step 6: Optional Configurations

### 6.1 Add environment variables (future use)

If you later add features that need API keys or config:

1. In Netlify, go to **Site settings** → **Build & deploy** → **Environment**
2. Click **Edit variables**
3. Add key-value pairs (e.g., `VITE_API_KEY = your_key`)
4. Re-deploy by pushing a commit to `main`

### 6.2 Enable branch previews

Every time you push a new branch to GitHub, Netlify creates a preview URL:
- Push to a branch called `feature/new-questions`
- Netlify auto-deploys it to `https://deploy-preview-1--story-brandtelling-net.netlify.app`
- Great for testing before merging to `main`

### 6.3 Monitor builds

Netlify shows build logs, deploy history, and performance metrics in the **Deploys** tab. If a build fails, you'll see the error logs.

---

## Ongoing Maintenance

### Making Updates

1. Edit files locally (e.g., add a new question to `src/StoryBuilder.jsx`)
2. Test with `npm run dev`
3. Commit and push:
   ```bash
   git add .
   git commit -m "Add new question about team size"
   git push
   ```
4. Netlify automatically redeploys (no manual action needed)

### Rollback

If you need to revert to a previous version:
1. Go to Netlify → **Deploys**
2. Click on an earlier deploy
3. Click **Publish deploy**

---

## Troubleshooting

### Build fails with "npm not found"

Netlify needs to detect Node.js. Ensure `package.json` is in the root directory and run `npm install` locally before pushing.

### Site loads but styling is broken

Check browser DevTools console for errors. Most common issue: CSS class names in Tailwind (if you were using it) won't work in Netlify. This build uses inline styles exclusively, so this shouldn't be a problem.

### Custom domain not working

- **Still shows `*.netlify.app` URL?** DNS propagation can take up to 24 hours. Wait and refresh.
- **SSL certificate error?** Netlify auto-generates it after DNS resolves. Wait 5–10 minutes after DNS propagates.
- **404 on subdomain?** Check that the CNAME record was added correctly in your DNS provider.

### Download button doesn't work

Downloads use the browser's native `blob` and `createElement` approach, which works in all modern browsers. Test in Chrome, Firefox, Safari, and Edge. If it fails in one, check the browser's console for errors.

---

## DNS Records Example (for GoDaddy)

If your domain is on GoDaddy:

1. Log in to GoDaddy
2. Go to **Domains** → Your domain → **Manage DNS**
3. Find or create a CNAME record:
   - **Name:** `story`
   - **Value:** `brandtelling-story-builder.netlify.app`
   - **TTL:** 1 hour
4. Save

Wait 5–30 minutes for propagation, then visit `https://story.brandtelling.net`.

---

## Production Checklist

Before considering the deployment "live":

- [ ] Site loads at `https://story.brandtelling.net`
- [ ] All 21 questions render and save answers
- [ ] Download file generates valid Markdown
- [ ] Navy/Gold/Cream design system displays correctly
- [ ] Mobile view (test on phone) is responsive
- [ ] Form validation prevents skipping required fields
- [ ] No console errors in browser DevTools
- [ ] HTTPS certificate shows as valid (green lock icon)

---

## Next Steps

- **Monitor analytics:** Enable Netlify Analytics to see traffic (optional paid feature)
- **Backup repository:** Your GitHub repo is your backup; commits are immutable
- **Document changes:** Keep commit messages clear so you can track what changed and when
- **Plan updates:** If you want to add new features (like passcode protection or user analytics), plan those changes locally first, test, then deploy

---

## Support

For issues:
- **Netlify:** [Netlify Support](https://support.netlify.com)
- **Vite:** [Vite Docs](https://vitejs.dev)
- **React:** [React Docs](https://react.dev)
- **Custom domain DNS:** Contact your domain registrar's support team

---

**Brandtelling® Story Builder** · AHG3, Inc.  
Deployed: `https://story.brandtelling.net`
