# Brandtelling® Story Builder — File Structure & Quick Reference

## Directory Layout

```
brandtelling-story-builder/
│
├── public/
│   └── (favicon and static assets — optional; currently handled via HTML)
│
├── src/
│   ├── main.jsx              ← React entry point (imports StoryBuilder)
│   └── StoryBuilder.jsx       ← Main component (all UI, logic, styling)
│
├── index.html                 ← HTML shell (minimal; React mounts to #root)
├── vite.config.js             ← Build tool configuration
├── package.json               ← Dependencies & scripts
├── netlify.toml               ← Netlify build & deployment rules
├── .gitignore                 ← Git ignore patterns
└── NETLIFY-DEPLOYMENT.md      ← This guide
```

---

## Key Files Explained

### `package.json`
Declares npm dependencies and build scripts:
- `npm run dev` → Start local dev server on `http://localhost:3000`
- `npm run build` → Create optimized `dist/` folder for production
- Dependencies: React, React-DOM, Lucide icons, Vite

### `vite.config.js`
Configures Vite (the build tool):
- Tells Vite to use React plugin
- Sets output directory to `dist/`
- Configures source maps and chunk naming for production

### `netlify.toml`
Netlify-specific configuration:
- Build command: `npm run build`
- Publish directory: `dist`
- Redirects all routes to `index.html` (needed for React Router, if added later)
- Security headers included

### `index.html`
Minimal HTML shell:
- Contains `<div id="root"></div>` where React mounts
- Meta tags for SEO, theme color, og:tags
- Loads `/src/main.jsx` as a module

### `src/main.jsx`
React bootstrap:
- Imports React, ReactDOM, and the StoryBuilder component
- Mounts StoryBuilder to `#root`

### `src/StoryBuilder.jsx`
Main component:
- All 21 questions, state management, and UI
- Design system colors (Navy, Gold, Cream, etc.)
- Typography rules (Georgia, Helvetica Neue)
- Form validation, download logic
- ~700 lines of self-contained React

---

## Quick Setup (Command Line)

```bash
# Clone from GitHub
git clone https://github.com/YOUR-USERNAME/brandtelling-story-builder.git
cd brandtelling-story-builder

# Install dependencies
npm install

# Run locally
npm run dev

# Build for production
npm run build

# Push to GitHub (after making changes)
git add .
git commit -m "Your message here"
git push
```

Netlify automatically deploys after `git push`.

---

## Environment Setup

### Local Development

**Requirements:**
- Node.js 18+ (check with `node --version`)
- npm 9+ (check with `npm --version`)
- A code editor (VS Code recommended)

**Recommended VS Code Extensions:**
- ES7+ React/Redux/React-Native snippets
- Prettier (code formatter)
- ESLint (linter)

### Production (Netlify)

**Netlify auto-detects:**
- Node.js version from `package.json` engines field (currently 18+)
- Build command from `netlify.toml`
- Deploy directory from `netlify.toml`

No additional configuration needed after initial setup.

---

## Design System Reference

**Colors** (used in `StoryBuilder.jsx`):
```javascript
const C = {
  navy:     "#1B2A4A",    // Primary text, buttons, headings
  gold:     "#B8922A",    // Accents, labels, highlights
  cream:    "#F7F5F0",    // Page background
  white:    "#ffffff",    // Cards
  softBg:   "#FAFAF8",    // Input backgrounds
  border:   "#E8E4DC",    // Borders, dividers
  muted:    "#5C6070",    // Secondary text
  light:    "#9A9488",    // Tertiary text, inactive elements
  error:    "#C0392B",    // Validation errors
  inactive: "#D9D5CC",    // Disabled states
  success:  "#EDF2EC",    // (reserved for future use)
};
```

**Typography:**
```javascript
const serif = "Georgia, 'Times New Roman', serif";
const sans  = "'Helvetica Neue', Arial, sans-serif";

// Usage:
// Headings: fontFamily: serif, fontWeight: 600-700
// Body:     fontFamily: serif, fontWeight: 400
// UI/labels: fontFamily: sans, textTransform: 'uppercase', fontSize: 11-13px
```

---

## Deployment Workflow

```
Local Development
      ↓
Edit files locally
      ↓
Test with `npm run dev`
      ↓
Commit to GitHub
      ↓
Git push
      ↓
Netlify detects push
      ↓
Runs `npm run build`
      ↓
Publishes `dist/` folder
      ↓
Live at https://story.brandtelling.net
```

---

## Common Tasks

### Add a new question

1. Open `src/StoryBuilder.jsx`
2. Find the `screens` array (around line 50)
3. Add a new screen object:
   ```javascript
   { type: 'text', key: 'myNewField', title: 'Your question?', placeholder: 'Your hint' }
   ```
4. Add a default value in the `answers` state initialization
5. Test locally with `npm run dev`
6. Push to GitHub

Netlify redeploys automatically.

### Update colors

1. Open `src/StoryBuilder.jsx`
2. Modify the `C` object at the top
3. Test locally
4. Push to GitHub

All colors are defined in one place; changes cascade everywhere.

### Change typography

1. Update the `serif` or `sans` constants at the top of `StoryBuilder.jsx`
2. OR update the `fontFamily` properties on individual style objects
3. Test and push

---

## Useful Commands

```bash
# View local server logs
npm run dev

# Build and preview production version locally
npm run build && npm run preview

# Check for unused packages
npm ls

# Update all packages
npm update

# Remove node_modules and reinstall (if something breaks)
rm -rf node_modules package-lock.json && npm install
```

---

## Git Workflow

### Initial push (already done)
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR-USERNAME/repo.git
git push -u origin main
```

### Subsequent pushes
```bash
git add .
git commit -m "Clear description of changes"
git push
```

### View commit history
```bash
git log --oneline
```

### Revert to a previous commit
```bash
git revert COMMIT_HASH
git push
```

---

## Performance Tips

- Netlify caches `dist/` builds; use `git push --force` to force redeploy (use sparingly)
- Enable Netlify Analytics (paid) to track real user traffic
- Monitor bundle size: check the Netlify deploy logs for asset sizes
- Use browser DevTools to check for console errors

---

## SSL/HTTPS

Netlify automatically:
- Provisions an SSL certificate via Let's Encrypt
- Redirects HTTP → HTTPS
- Renews certificates before expiration

No action required.

---

## Support Files Included

- **NETLIFY-DEPLOYMENT.md** — Full step-by-step deployment guide
- **netlify.toml** — Build configuration
- **package.json** — Dependency manifest
- **vite.config.js** — Build tool config
- **.gitignore** — Git ignore rules
- **index.html** — HTML entry point
- **src/main.jsx** — React bootstrap
- **src/StoryBuilder.jsx** — Main component

All files are ready to deploy as-is. No additional configuration needed.

---

## Questions?

Refer to the **NETLIFY-DEPLOYMENT.md** for step-by-step instructions or check:
- [Netlify Docs](https://docs.netlify.com)
- [Vite Docs](https://vitejs.dev)
- [React Docs](https://react.dev)

---

**Brandtelling® Story Builder** · AHG3, Inc.
