# Brandtelling® Story Builder — Complete File Manifest

## All Files for Netlify Deployment

Below is the complete list of files needed to deploy the Story Builder to Netlify. All files are in `/mnt/user-data/outputs/`.

---

## Root-Level Configuration Files

### `package.json` (Required)
**Purpose:** NPM package manifest  
**Size:** ~500 bytes  
**Contains:** Dependencies, build scripts, Node version  
**Do Not Edit:** Unless adding new packages  
**Usage:** Netlify reads this to know how to build your project

### `vite.config.js` (Required)
**Purpose:** Vite build tool configuration  
**Size:** ~300 bytes  
**Contains:** React plugin setup, output paths, dev server config  
**Do Not Edit:** Settings are optimized for Netlify  
**Usage:** Runs `npm run build` — generates `dist/` folder

### `netlify.toml` (Required)
**Purpose:** Netlify-specific configuration  
**Size:** ~600 bytes  
**Contains:** Build command, publish directory, redirects, security headers  
**Do Not Edit:** Unless customizing security rules  
**Usage:** Netlify reads this on deploy to know where publish the built files

### `index.html` (Required)
**Purpose:** HTML entry point  
**Size:** ~1.2 KB  
**Contains:** Minimal HTML shell, meta tags, React mount point  
**Do Not Edit:** Unless changing page title or meta tags  
**Usage:** Browser loads this first; React mounts to `#root`

### `.gitignore` (Required)
**Purpose:** Tell Git which files to ignore  
**Size:** ~500 bytes  
**Contains:** `node_modules/`, `dist/`, `.DS_Store`, etc.  
**Do Not Edit:** Standard patterns  
**Usage:** Prevents large folders from being committed to GitHub

---

## Source Code (React Components)

### `src/main.jsx` (Required)
**Purpose:** React entry point  
**Size:** ~200 bytes  
**Contains:** React bootstrap, ReactDOM.createRoot, component import  
**Do Not Edit:** Very minimal  
**Usage:** Vite uses this to start React

### `src/StoryBuilder.jsx` (Required)
**Purpose:** Main Story Builder component  
**Size:** ~30 KB  
**Contains:** All UI, state, styling, logic for 21-question flow  
**Edit:** To add questions, change colors, modify labels  
**Usage:** The entire application runs in this file

---

## Documentation Files (Optional but Helpful)

### `NETLIFY-DEPLOYMENT.md` (Recommended)
**Purpose:** Complete step-by-step deployment guide  
**Size:** ~8 KB  
**Contains:** Setup from zero to live at custom domain  
**Read This:** First time setting up  
**Keep It:** Reference for future deployments

### `QUICK-START.md` (Recommended)
**Purpose:** Deployment checklist  
**Size:** ~6 KB  
**Contains:** Checkboxes for each step, quick commands, troubleshooting  
**Read This:** Before starting deployment  
**Keep It:** Alongside `NETLIFY-DEPLOYMENT.md`

### `FILE-STRUCTURE.md` (Recommended)
**Purpose:** Explanation of all files and how they work together  
**Size:** ~5 KB  
**Contains:** File-by-file breakdown, design system reference, common tasks  
**Read This:** To understand the codebase  
**Keep It:** For onboarding or future edits

---

## Summary: Total Files to Copy

```
brandtelling-story-builder/
├── package.json                          ← Install npm packages
├── vite.config.js                        ← Build configuration
├── netlify.toml                          ← Netlify deployment settings
├── .gitignore                            ← Git ignore rules
├── index.html                            ← HTML shell
├── src/
│   ├── main.jsx                          ← React bootstrap
│   └── StoryBuilder.jsx                  ← Main component (entire app)
└── docs/ (optional)
    ├── NETLIFY-DEPLOYMENT.md             ← Full deployment guide
    ├── QUICK-START.md                    ← Deployment checklist
    └── FILE-STRUCTURE.md                 ← File explanations
```

---

## What Gets Generated During Build

When you run `npm run build`, Netlify creates a `dist/` folder (NOT in the repo):

```
dist/
├── index.html                    ← Compiled with bundled JS
├── js/
│   ├── [name].[hash].js         ← React + your code bundled
│   └── [name].[hash].js         ← Vendor code (lucide, react, etc.)
└── assets/
    └── [name].[hash].css         ← If any CSS files exist
```

**This `dist/` folder is what gets deployed to Netlify.** The files above are what's in your Git repo.

---

## File Sizes & Performance

| File | Size | Purpose |
|------|------|---------|
| `package.json` | 0.5 KB | Dependencies manifest |
| `vite.config.js` | 0.3 KB | Build config |
| `netlify.toml` | 0.6 KB | Netlify config |
| `index.html` | 1.2 KB | HTML shell |
| `.gitignore` | 0.5 KB | Git ignore |
| `src/main.jsx` | 0.2 KB | React bootstrap |
| `src/StoryBuilder.jsx` | 30 KB | Main component |
| **Total Source** | **33 KB** | All source code |
| **After Build (dist/)** | ~80–120 KB | Minified + gzipped |
| **Browser Download** | ~30–40 KB | Gzipped transfer size |

---

## Download Instructions

All files are in `/mnt/user-data/outputs/`:

### Download as ZIP (Easiest)
1. Go to `/mnt/user-data/outputs/` (in your file system)
2. Select all files and folders:
   - `brandtelling-story-builder.jsx` (ignore this — was the artifact)
   - `src/` folder
   - `index.html`
   - `package.json`
   - `vite.config.js`
   - `netlify.toml`
   - `.gitignore`
   - `NETLIFY-DEPLOYMENT.md`
   - `QUICK-START.md`
   - `FILE-STRUCTURE.md`
3. Right-click → **Compress** (Mac) or **Send to → Compressed folder** (Windows)
4. Save as `brandtelling-story-builder.zip`

### Download Individual Files
- Download each file listed above separately to your local folder
- Ensure `src/main.jsx` and `src/StoryBuilder.jsx` are in a `src/` subdirectory

---

## Git Setup Quick Commands

```bash
# After copying files to local folder:
cd brandtelling-story-builder
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR-USERNAME/brandtelling-story-builder.git
git push -u origin main
```

---

## Netlify Connect Quick Commands

1. Create GitHub repo at [github.com/new](https://github.com/new)
2. Push your local code (commands above)
3. Go to [app.netlify.com](https://app.netlify.com)
4. Click **Add new site → Import an existing project → GitHub**
5. Select your repo → Deploy
6. Wait 2–3 minutes
7. Go to **Site settings → Domain management → Add custom domain**
8. Enter `story.brandtelling.net`
9. Update DNS records in your domain registrar (GoDaddy, Namecheap, etc.)
10. Wait 5–30 minutes for DNS to propagate
11. Visit `https://story.brandtelling.net` ✅

---

## File Edit Permission Matrix

| File | Edit Locally | Edit on Netlify | Edit in Production |
|------|--------------|-----------------|-------------------|
| `src/StoryBuilder.jsx` | ✅ Yes | ❌ No | ❌ No (must commit) |
| `package.json` | ✅ Yes (if adding packages) | ❌ No | ❌ No |
| `netlify.toml` | ✅ Yes | ❌ No | ❌ No |
| `index.html` | ✅ Yes | ❌ No | ❌ No |
| Other files | ✅ Yes | ❌ No | ❌ No |

**All edits must be made locally, committed to Git, and pushed. Netlify auto-deploys after push.**

---

## Deployment Workflow

```
Local Edit
    ↓
`npm run dev` (test locally)
    ↓
`git add . && git commit && git push`
    ↓
GitHub receives push
    ↓
Netlify webhook triggered
    ↓
Netlify runs `npm run build`
    ↓
Netlify publishes `dist/` to CDN
    ↓
`https://story.brandtelling.net` updated (1–2 min)
    ↓
Visit URL to see live changes
```

---

## Validation Checklist

After setup, verify:

- [ ] All files in correct directories (use `FILE-STRUCTURE.md` as guide)
- [ ] `npm install` completes without errors
- [ ] `npm run dev` loads Story Builder on localhost:3000
- [ ] All 21 questions display
- [ ] Styling (Navy/Gold/Cream) is correct
- [ ] Download button works and generates `.md` file
- [ ] `git push` triggers Netlify deploy
- [ ] `https://story.brandtelling.net` is live after DNS propagates
- [ ] HTTPS certificate shows as valid (green lock)

---

## File Manifest Summary

**Required (Must Deploy):**
- `package.json`
- `vite.config.js`
- `netlify.toml`
- `index.html`
- `.gitignore`
- `src/main.jsx`
- `src/StoryBuilder.jsx`

**Recommended (Reference):**
- `NETLIFY-DEPLOYMENT.md`
- `QUICK-START.md`
- `FILE-STRUCTURE.md`

**Optional (Design System Reference):**
- Any documentation about the Brandtelling design system

---

**Total Required Files:** 7  
**Recommended Total:** 10  
**Estimated Deployment Time:** 1–2 hours (first time; mostly DNS wait)  
**Ongoing Update Time:** 5 minutes per change (just `git push`)

---

Brandtelling® Story Builder · AHG3, Inc.
